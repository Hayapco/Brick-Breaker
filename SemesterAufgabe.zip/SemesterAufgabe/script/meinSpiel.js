var canvas = document.querySelector('canvas');
var ctx = canvas.getContext('2d');
var affichageScore = document.querySelector('.score');
var rayonBalle = 10, barreHeight = 10, barreWidth = 75, nbCol = 10, nbRow = 8, largeurBrique = 75, hauteurBrique = 20;
var x = canvas.width / 2, y = canvas.height - 30, barreX = (canvas.width - barreWidth) / 2, fin = false, vitesseX = 5, vitesseY = -5, score = 0;
function dessineBalle() {
    ctx === null || ctx === void 0 ? void 0 : ctx.beginPath();
    ctx === null || ctx === void 0 ? void 0 : ctx.arc(x, y, rayonBalle, 0, Math.PI * 2);
    ctx.fillStyle = '#333';
    ctx === null || ctx === void 0 ? void 0 : ctx.fill();
    ctx === null || ctx === void 0 ? void 0 : ctx.closePath();
}
// dessineBalle();
function dessineBarre() {
    ctx === null || ctx === void 0 ? void 0 : ctx.beginPath();
    ctx === null || ctx === void 0 ? void 0 : ctx.rect(barreX, canvas.height - barreHeight - 2, barreWidth, barreHeight);
    ctx.fillStyle = '#333';
    ctx === null || ctx === void 0 ? void 0 : ctx.fill();
    ctx === null || ctx === void 0 ? void 0 : ctx.closePath();
}
// dessineBarre();
// Tableau avec toutes les briques
var briques = [];
for (var i = 0; i < nbRow; i++) {
    //const arrayLeer: number [] = [];
    // briques[i] = arrayLeer[i]
    briques[i] = [];
    for (var j = 0; j < nbCol; j++) {
        briques[i][j] = { x: 0, y: 0, statut: 1 };
    }
}
// console.log(briques);
function dessineBriques() {
    for (var i = 0; i < nbRow; i++) {
        for (var j = 0; j < nbCol; j++) {
            if (briques[i][j].statut === 1) {
                // 75 * 8 + 10 * 8 + 35 = 750
                var briqueX = (j * (largeurBrique + 10) + 35);
                var briqueY = (i * (hauteurBrique + 10) + 30);
                briques[i][j].x = briqueX;
                briques[i][j].y = briqueY;
                ctx === null || ctx === void 0 ? void 0 : ctx.beginPath();
                ctx === null || ctx === void 0 ? void 0 : ctx.rect(briqueX, briqueY, largeurBrique, hauteurBrique);
                ctx.fillStyle = '#333';
                ctx === null || ctx === void 0 ? void 0 : ctx.fill();
                ctx === null || ctx === void 0 ? void 0 : ctx.closePath();
            }
        }
    }
}
// dessineBriques();
function dessine() {
    if (fin === false) {
        ctx === null || ctx === void 0 ? void 0 : ctx.clearRect(0, 0, canvas.width, canvas.height);
        dessineBriques();
        dessineBalle();
        dessineBarre();
        collisionDetection();
        if (x + vitesseX > canvas.width - rayonBalle || x + vitesseX < rayonBalle) {
            vitesseX = -vitesseX;
        }
        if (y + vitesseY < rayonBalle) {
            vitesseY = -vitesseY;
        }
        if (y + vitesseY > canvas.height - rayonBalle) {
            // un intervalle
            // 0 - 75
            if (x > barreX && x < barreX + barreWidth) {
                vitesseX = vitesseX + 0.1;
                vitesseY = vitesseY + 0.1;
                vitesseY = -vitesseY;
            }
            else {
                fin = true;
                affichageScore.innerHTML = "Perdu ! <br> Clique sur le casse-briques pour recommencer.";
            }
        }
        x += vitesseX;
        y += vitesseY;
        requestAnimationFrame(dessine);
    }
}
dessine();
function collisionDetection() {
    for (var i = 0; i < nbRow; i++) {
        for (var j = 0; j < nbCol; j++) {
            var b = briques[i][j];
            if (b.statut === 1) {
                if (x > b.x && x < b.x + largeurBrique && y > b.y && y < b.y + hauteurBrique) {
                    vitesseY = -vitesseY;
                    b.statut = 0;
                    score++;
                    affichageScore.innerHTML = "Score : ".concat(score);
                    if (score === nbCol * nbRow) {
                        affichageScore.innerHTML = "Bravo ! <br> Clique sur le casse-briques pour recommencer.";
                        fin = true;
                    }
                }
            }
        }
    }
}
// Mouvement de la barre
document.addEventListener('mousemove', mouvementSouris);
function mouvementSouris(e) {
    var posXBarreCanvas = e.clientX - canvas.offsetLeft;
    // e.clienX = de la gauche jusqu'à la souris
    // canvas.offsetLeft = décalage par rapport à la gauche
    // console.log(posXBarreCanvas);
    if (posXBarreCanvas > 35 && posXBarreCanvas < canvas.width - 35) {
        barreX = posXBarreCanvas - barreWidth / 2;
    }
}
// Recommencer
canvas === null || canvas === void 0 ? void 0 : canvas.addEventListener('click', function () {
    if (fin === true) {
        fin = false;
        document.location.reload();
    }
});
