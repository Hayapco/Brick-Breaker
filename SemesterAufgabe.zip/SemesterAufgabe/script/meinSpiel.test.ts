import {draw} from './meinSpiel'
import {speedY} from './meinSpiel'
import {speedX} from './meinSpiel'
import { collisionDetection } from './meinSpiel';
import { end } from './meinSpiel';
import{canvas} from './meinSpiel';

test ('speedY', () => {
    let scape = speedY;
    draw()
    expect(speedY).toBe(-scape)

})
    
test('speedX', ()=> {
        let a = speedX
        draw()
        expect(speedX).toBe(a + 0.1)

    })

test('end', ()=> {
    let fin = end;
    collisionDetection()
    expect(end).toBe(true)
})