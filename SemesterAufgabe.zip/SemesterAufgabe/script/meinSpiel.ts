export const canvas:HTMLCanvasElement | null = document.querySelector('canvas');
const ctx:CanvasRenderingContext2D | null = canvas!.getContext('2d');
const spielStand:HTMLHeadingElement|null = document.querySelector('.score');




const radiusBall:number = 10, stabHeight:number = 10, stabWidth:number =75,
nbCol:number = 10, nbRow:number = 8, brickWidth:number = 75, brickHeight:number = 20;

export let x:number  = canvas!.width/2, y:number = canvas!.height -30,
stabX:number = (canvas!.width - stabWidth)/2, end:boolean = false,
speedX:number = 5, speedY:number = -5, score:number = 0;

function drawBall():void{

    ctx?.beginPath();
    ctx?.arc(x,y, radiusBall, 0, Math.PI*2);
    ctx!.fillStyle = '#333';
    ctx?.fill();
    ctx?.closePath();

}
// dessineBalle();


function drawStab():void{

    ctx?.beginPath();
    ctx?.rect(stabX, canvas!.height - stabHeight - 2, stabWidth, stabHeight)
    ctx!.fillStyle = '#333';
    ctx?.fill();
    ctx?.closePath();

}
// dessineBarre();

// Tableau avec toutes les briques
let bricks:{
    x:number,
    y:number,
    statut:number
}[][] = []
 
for(let i = 0; i < nbRow; i++){
//const arrayLeer: number [] = [];
  // briques[i] = arrayLeer[i]
 bricks[i] = []
 for(let j = 0; j < nbCol; j++){

    bricks[i][j] = {x: 0, y: 0, statut: 1}
}

}
// console.log(briques);

function drawBricks():void{

    for(let i = 0; i < nbRow; i++){
        for(let j = 0; j < nbCol; j++){

            if(bricks[i][j].statut === 1){

                // 75 * 8 + 10 * 8 + 35 = 750
                let brickX:number = (j * (brickWidth + 10) + 35);
                let brickY:number = (i * (brickHeight + 10) + 30);

                bricks[i][j].x = brickX;
                bricks[i][j].y = brickY;

                ctx?.beginPath();
                ctx?.rect(brickX, brickY, brickWidth, brickHeight);
                ctx!.fillStyle = '#333';
                ctx?.fill();
                ctx?.closePath();
            }

        }
    }

}
// dessineBriques();


export function draw(){

    if(end === false){

        ctx?.clearRect(0, 0, canvas!.width, canvas!.height);
        drawBricks();
        drawBall();
        drawStab();
        collisionDetection();

        if(x + speedX > canvas!.width - radiusBall || x + speedX < radiusBall){
            speedX = -speedX;
        }
        
        if(y + speedY < radiusBall){
            speedY = -speedY;
        }

        if(y + speedY > canvas!.height - radiusBall){

            // un intervalle
            // 0 - 75
            if(x > stabX && x < stabX + stabWidth){
                speedX = speedX + 0.1;
                speedY = speedY + 0.1;
                speedY = -speedY;
            }
            else {
                end = true;
                spielStand!.innerHTML = `Verloren ! <br> Klicken sie auf dem Backstein um erneut zu spielen.`
            }
    }


        x += speedX;
        y += speedY;
        requestAnimationFrame(draw);

    }

}
draw();

export function collisionDetection(){

    for(let i = 0; i < nbRow; i++){
        for(let j = 0; j < nbCol; j++){

            let b = bricks[i][j];
            if(b.statut === 1){
                if(x > b.x && x < b.x + brickWidth && y > b.y && y < b.y + brickHeight){
                    speedY = -speedY;
                    b.statut = 0;

                    score++;
                    spielStand!.innerHTML = `Score : ${score}`;

                    if(score === nbCol * nbRow){

                        spielStand!.innerHTML = `Herzlich Glückwünsch ! <br> Klicken sie auf dem Backstein um erneut zu starten.`
                        end = true;

                    }
                }
            }

        }
    }

}



// Mouvement de la barre

document.addEventListener('mousemove', movementMaus);

function movementMaus(e:any){

    let posXBarreCanvas = e.clientX - canvas!.offsetLeft;
    // e.clienX = de la gauche jusqu'à la souris
    // canvas.offsetLeft = décalage par rapport à la gauche
    // console.log(posXBarreCanvas);

    if(posXBarreCanvas > 35 && posXBarreCanvas < canvas!.width - 35){
        stabX = posXBarreCanvas - stabWidth/2;
    }

}





// Recommencer
canvas?.addEventListener('click', () => {

    if(end === true){
        end = false;
        document.location.reload();
    }

})