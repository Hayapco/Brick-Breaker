# *Brick-breaker*

### Brick-breaker ist ein Spiel, wobei das Ziel ist, alle Bricks zu zerschlagen und dabei zu vermeiden, dass der Ball nicht auf der Stab landet.

## *Technologies used*

* Typescript
* Html
* CSS

## *Author*
 Das Projekt wurde von Hayap Yamdjeu Corinne (ich) codiert.

## *Zum Ausführen*
mit dem Index File öffnen